﻿using Microsoft.AspNetCore.Mvc;

namespace assignment01_gbcbids.Controllers
{
    public class ContactController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
