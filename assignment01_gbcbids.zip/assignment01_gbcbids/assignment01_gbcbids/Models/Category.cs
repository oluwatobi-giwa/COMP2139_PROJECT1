﻿namespace assignment01_gbcbids.Models
{
    public class Category
    {
    }
}
